package order.server.model;

public class TransactionResponse {

}
